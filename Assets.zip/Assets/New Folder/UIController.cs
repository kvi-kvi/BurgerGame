using UnityEngine;

public class UIController : MonoBehaviour
{
    public GameObject inputPanel;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            inputPanel.SetActive(!inputPanel.activeSelf);
        }
    }
}