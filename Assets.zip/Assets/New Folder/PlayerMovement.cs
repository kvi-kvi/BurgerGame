using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 5f;

    void Update()
    {
        float moveX = Input.GetAxis("Horizontal");
        transform.position += new Vector3(moveX, 0, 0) * speed * Time.deltaTime;
    }
}